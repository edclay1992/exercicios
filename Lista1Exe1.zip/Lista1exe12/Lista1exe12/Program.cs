﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1exe12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
            double d;
            double e;
            double f;
            double g;

            Console.WriteLine("Digite os 5 valores dos produtos");
            a = Double.Parse(Console.ReadLine());
            b = Double.Parse(Console.ReadLine());
            c = Double.Parse(Console.ReadLine());
            d = Double.Parse(Console.ReadLine());
            e = Double.Parse(Console.ReadLine());

            f = a + b + c + d + e;

            Console.WriteLine("Valor Total é {0}", f);

            Console.WriteLine("Digite o Valor para pagamento");
            g = Double.Parse(Console.ReadLine());

            double h = g - f;

            Console.WriteLine("Seu troco é {0}", h);
        }
    }
}
