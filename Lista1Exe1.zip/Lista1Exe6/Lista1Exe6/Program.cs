﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            double y;
           
            Console.WriteLine("Digite o valor Inicial");
            x = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor Final");
            y = Double.Parse(Console.ReadLine());

            double a = x * y;

            double b = Math.Sqrt(a);
                     

            Console.WriteLine("A média geométrica é {0}", b);

        }
    }
}
