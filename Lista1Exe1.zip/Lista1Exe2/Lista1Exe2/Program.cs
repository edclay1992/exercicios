﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double a;

            Console.WriteLine("Digite o Valor da aresta");
            a = double.Parse(Console.ReadLine());

            aresta = a * a;
            Console.WriteLine("Total da área do Quadrado é {0} m²", aresta);

        }
    }
}
