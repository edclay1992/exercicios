﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double d;
            double a;
            double b;
            double c;

            Console.WriteLine("Digite o Valor da Diagonal");
            c = double.Parse(Console.ReadLine());
            b = 2 ;

            d = c * c;

            a = d / b;
            
            Console.WriteLine("Total da área do quadrado é {0} m²", a);
        }
    }
}
