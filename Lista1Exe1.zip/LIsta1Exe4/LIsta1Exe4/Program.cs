﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIsta1Exe4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double h;
            double c;

            Console.WriteLine("Digite o valor da Base");
            b = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da Altura");
            h = double.Parse(Console.ReadLine());

            c = 2;

            a = b * h / c;

            Console.WriteLine("Total da área do Triângulo é {0}", a);

        }
    }
}
