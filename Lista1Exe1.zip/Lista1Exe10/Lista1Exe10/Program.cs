﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
            
            Console.WriteLine("Digite a Cotação (Reais)");
            a = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite a quantidade de Doláres");
            b = Double.Parse(Console.ReadLine());

            c = a * b;

            Console.WriteLine("Equivale a R$ {0} reais", c);
            
        }
    }
}
