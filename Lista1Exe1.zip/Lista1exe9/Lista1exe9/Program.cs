﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1exe9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
            double d;

            Console.WriteLine("Digite o diâmetro do circulo");
            a = Double.Parse(Console.ReadLine());

            c = Math.Pow(a, 2);
            b = Math.PI * c / 4;
            
            Console.WriteLine("O total de sua área é {0}", b);
        }
    }
}
