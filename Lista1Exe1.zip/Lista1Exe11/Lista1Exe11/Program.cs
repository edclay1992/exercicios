﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            double y;
            Console.WriteLine("Digite o valor de X");
            x = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor de Y");
            y = Double.Parse(Console.ReadLine());
            double v1 = Math.Pow(x, y);
            double v = v1;
            Console.WriteLine("Total é {0}", v);
        }
    }
}
