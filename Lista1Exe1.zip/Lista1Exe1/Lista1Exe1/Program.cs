﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double h;
            double a;

            Console.WriteLine("Digite o valor da Base");
            b = Double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da Altura");
            h = Double.Parse(Console.ReadLine());

            a = b * h;

            Console.WriteLine("Total da área do Retângulo é {0}", a);


        }
    }
}
