﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
            double d;
            double e;
            double f;

            Console.WriteLine("Digite o valor");
            a = double.Parse(Console.ReadLine());
            b = double.Parse(Console.ReadLine());
            c = double.Parse(Console.ReadLine());
            d = double.Parse(Console.ReadLine());

            e = 4;

            f = a + b + c + d / e;

            Console.WriteLine("Total da média aritimética é {0}", f);

        }
    }
}
