﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.WriteLine("Digite o valor em Milhas");
            a = Double.Parse(Console.ReadLine());

            b = 1.852;

            double c = a * b;

            Console.WriteLine("O total é {0} Km", c);

        }
    }
}
