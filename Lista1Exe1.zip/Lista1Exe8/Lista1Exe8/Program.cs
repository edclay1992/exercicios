﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Exe8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
            double d;

            Console.WriteLine("Digite a temperatura em C° (grau celsius)");
            a = Double.Parse(Console.ReadLine());

            b = a * 9 / 5;
            d = b + 32;

            Console.WriteLine("O resultado é {0} F° (grau fahrenheit)", d);
        }
    }
}
